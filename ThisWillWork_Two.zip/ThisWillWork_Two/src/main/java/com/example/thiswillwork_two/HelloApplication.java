//importing the classes
package com.example.thiswillwork_two;
import javafx.application.Application;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.StackPane;
import javafx.scene.paint.Color;
import javafx.stage.Stage;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import javafx.scene.layout.VBox;

public class HelloApplication extends Application {
    SeperatingInsideCharities splitIndividual = new SeperatingInsideCharities();
    ArrayList<String> names = SeperatingInsideCharities.getName();
    private SeperatingCharities charityInstance;
    private List<String> charities;
    private String selectedCharity;
    private ArrayList<String> selectedList;


    @Override
    public void start(Stage stage) {
        TabPane tabPane = new TabPane();

        //in this part we are creating the tabs for choosing whether to go into charity info or the add charity
        Tab tab1 = new Tab();
        tab1.setText("Charity Info: ");
        tab1.setContent(new StackPane()); // Add content to the first tab
        StackPane contentPane5 = new StackPane();
        ScrollPane scrollPane = new ScrollPane();//adding a scroll feature
        scrollPane.setContent(CharityInfo());//add the content for the pane the CharityInfo class, checl below
        //we added a CharityInfo class, which prints all the info pertinant to the charity info
        scrollPane.setFitToWidth(true); // Allow the ScrollPane to resize horizontally, ensure it fits
        VBox tabContent = new VBox();
        tabContent.getChildren().addAll(contentPane5, scrollPane);//add all the contents to the actual pane
        tab1.setContent(tabContent);//set it



//same principle here as above, just were adding a charity, and instead of taking from the CharityInfo, were taking from
        // the AddDonation class, which required parameters, selectedCharity, splitIndividual, we use later on, these are just placeholders
        Tab tab2 = new Tab();
        tab2.setText("Add Charity: ");
        tab2.setContent(new StackPane()); // Add content to the first tab
        StackPane contentPane2 = new StackPane();
        ScrollPane scrollPane2 = new ScrollPane();
        scrollPane2.setContent(AddDonation(selectedCharity, splitIndividual));
        scrollPane2.setFitToWidth(true); // Allow the ScrollPane to resize horizontally
        VBox tabContent2 = new VBox();
        tabContent2.getChildren().addAll(contentPane2, scrollPane2);
        tab2.setContent(tabContent2);

        tabPane.getTabs().addAll(tab1, tab2);//adding the tabs to the page
        Scene scene = new Scene(tabPane, 400, 300);//defining how large panes are

        // Set the scene to the stage and show the stage
        stage.setScene(scene);
        stage.setTitle("Charity Application (workkk) ");
        stage.show();//show everything
    }


public VBox CharityInfo(){//charity info class, which is under tab1, used in line:  scrollPane.setContent(CharityInfo());
    Stage charityInfoStage = new Stage(); // Create a new stage
    VBox content = new VBox();

    charities = Arrays.asList(   "Tagtune", "Wikibox", "Roombo", "Trudoo", "Yakitri", "Tagfeed", "Podcat", "Kwimbee", "Minyx",
            "Ntags", "Thoughtstorm", "Devpulse", "Kaymbo", "Jabbersphere", "Gigabox", "Meemm", "Gigazoom",
            "Dabvine", "Skilith", "Realcube", "Gabvine", "Pixoboo", "Skyble", "Babbleblab", "Shuffletag",
            "Thoughtsphere", "Centimia", "Snaptags", "Leenti", "Dynava", "Buzzster", "Twitterworks", "Shufflester",
            "DabZ", "Meezzy", "Eire", "Izio", "Photobean", "Yodoo"
    );
    final ComboBox comboBox = new ComboBox();//combobox is the dropdown option, were defining a new dropdown
    //titles comboBox

    comboBox.setPromptText("Select a charity");//the text on top of the comboBox is select a charity

    comboBox.getItems().addAll(charities);//for all the charaties defined in charaties arraylist, add a dropdown option for each

    StackPane root = new StackPane();
    root.getChildren().addAll(comboBox);
    StackPane.setAlignment(comboBox, javafx.geometry.Pos.TOP_CENTER);//set the comboBox position to the Top Center
    // Scene scene = new Scene(tabPane, 400, 300);

    Scene scene = new Scene(root, 400, 300);//width and length

    comboBox.setOnAction(e -> {//when the combobox is clicked...
        String selectedValue = (String) comboBox.getValue(); // Get the selected value from the ComboBox, what option did you clidk, what value, as in is it Shufflester (a charity option)

        // Update selectedCharity when the ComboBox value changes
        selectedCharity = selectedValue;

        // Call NewPane method with the updated selectedCharity, when its selected, call NewPane, which is a class we created below, which will open a new pane
        NewPane(selectedCharity);
    });


    // Set the scene to the stage and show the stage
    charityInfoStage.setScene(scene);
    charityInfoStage.setTitle("Simple JavaFX Application");
    charityInfoStage.show();
    content.getChildren().add(root);
    return content;
}

//this is the NewPane class, which we called in this line: NewPane(selectedCharity);, it is the class where we see all the charity info
    public void NewPane(String charity){
        //the switch is saying when you select a charity, make the selectedList the arrayList of that charity, we will use  selectedList later on
        // its saying if youre in ".." charity, make the selectedList value the arraylist of that charity
        switch (charity) {
            case "Tagtune":
                selectedList = SeperatingCharities.getTagtune();
                break;
            case "Wikibox":
                selectedList = SeperatingCharities.getWikibox();
                break;
            case "Roombo":
                selectedList = SeperatingCharities.getRoombo();
                break;
            case "Trudoo":
                selectedList = SeperatingCharities.getTrudoo();
                break;
            case "Yakitri":
                selectedList = SeperatingCharities.getYakitri();
                break;
            case "Tagfeed":
                selectedList = SeperatingCharities.getTagfeed();
                break;
            case "Podcat":
                selectedList = SeperatingCharities.getPodcat();
                break;
            case "Kwimbee":
                selectedList = SeperatingCharities.getKwimbee();
                break;
            case "Minyx":
                selectedList = SeperatingCharities.getMinyx();
                break;
            case "Ntags":
                selectedList = SeperatingCharities.getNtags();
                break;
            case "Thoughtstorm":
                selectedList = SeperatingCharities.getThoughtstorm();
                break;
            case "Devpulse":
                selectedList = SeperatingCharities.getDevpulse();
                break;
            case "Kaymbo":
                selectedList = SeperatingCharities.getKaymbo();
                break;
            case "Jabbersphere":
                selectedList = SeperatingCharities.getJabbersphere();
                break;
            case "Gigabox":
                selectedList = SeperatingCharities.getGigabox();
                break;
            case "Meemm":
                selectedList = SeperatingCharities.getMeemm();
                break;
            case "Gigazoom":
                selectedList = SeperatingCharities.getGigazoom();
                break;
            case "Dabvine":
                selectedList = SeperatingCharities.getDabvine();
                break;
            case "Skilith":
                selectedList = SeperatingCharities.getSkilith();
                break;
            case "Realcube":
                selectedList = SeperatingCharities.getRealcube();
                break;
            case "Gabvine":
                selectedList = SeperatingCharities.getGabvine();
                break;
            case "Pixoboo":
                selectedList = SeperatingCharities.getPixoboo();
                break;
            case "Skyble":
                selectedList = SeperatingCharities.getSkyble();
                break;
            case "Babbleblab":
                selectedList = SeperatingCharities.getBabbleblab();
                break;
            case "Shuffletag":
                selectedList = SeperatingCharities.getShuffletag();
                break;
            case "Thoughtsphere":
                selectedList = SeperatingCharities.getThoughtsphere();
                break;
            case "Centimia":
                selectedList = SeperatingCharities.getCentimia();
                break;
            case "Snaptags":
                selectedList = SeperatingCharities.getSnaptags();
                break;
            case "Leenti":
                selectedList = SeperatingCharities.getLeenti();
                break;
            case "Dynava":
                selectedList = SeperatingCharities.getDynava();
                break;
            case "Buzzster":
                selectedList = SeperatingCharities.getBuzzster();
                break;
            case "Twitterworks":
                selectedList = SeperatingCharities.getTwitterworks();
                break;
            case "Shufflester":
                selectedList = SeperatingCharities.getShufflester();
                break;
            case "DabZ":
                selectedList = SeperatingCharities.getDabZ();
                break;
            case "Meezzy":
                selectedList = SeperatingCharities.getMeezzy();
                break;
            case "Eire":
                selectedList = SeperatingCharities.getEire();
                break;
            case "Izio":
                selectedList = SeperatingCharities.getIzio();
                break;
            case "Photobean":
                selectedList = SeperatingCharities.getPhotobean();
                break;
            case "Yodoo":
                selectedList = SeperatingCharities.getYodoo();
                break;

        }
//getting all the required properties from SeperatingInsideCharities class
        ArrayList<String> names = SeperatingInsideCharities.getName();
        ArrayList<String> emails = SeperatingInsideCharities.getEmail();
        ArrayList<String> addresses = SeperatingInsideCharities.getAdress();
        ArrayList<String> taxNumbers = SeperatingInsideCharities.getTaxNumber();
        ArrayList<String> moneys = SeperatingInsideCharities.getMoney();
        ArrayList<String> months = SeperatingInsideCharities.getMonth();

//instantiating stuff
        SeperatingCharities Charity = new SeperatingCharities();
        Charity.readCSV(selectedList);
        SeperatingInsideCharities SplitIndividual = new SeperatingInsideCharities();


        Stage newStage = new Stage(); // Create a new stage
        BorderPane newPane = new BorderPane();
        newPane.setTop(new Label("The are currently viewing the charity: " + charity));

        TabPane tabPane = new TabPane();//creating new tabs inside the pane

        // Create tabs
        Tab tab1 = new Tab();
        tab1.setText("Donors"); //the title of the tab
        tab1.setContent(new StackPane()); // Add content to the first tab
        ArrayList<String> individual5 = SplitIndividual.splitInListDonor(selectedList, names);
        // This line seems is calling a method named splitInListDonor from the SplitIndividual object, passing selectedList and names as arguments.
        // so we are saying from SplitIndividual, which we instantiated above, get the splitInListDonor method, and use it in the selectedList
        //arraylist, which we defined in the switch arguments, and get the names (donors) of the arraylist
        //the selectedList is dependent in what charity you selected and are in, refer to the switch above
        Label addressLabel5 = new Label(individual5.toString());//this is saying create a new label, and with the info gathered
        //from individual5, above, turn it into a string and print it as a label in our panel
        StackPane contentPane5 = new StackPane();
        contentPane5.getChildren().add(addressLabel5);//adding the addressLabel5 to our panel
        ScrollPane scrollPane = new ScrollPane();//adding a scroll factor
        scrollPane.setContent(contentPane5);//use the scrollPane within the contentPane5
        scrollPane.setFitToWidth(true); // Allow the ScrollPane to resize horizontally
        VBox tabContent = new VBox();
        tabContent.getChildren().addAll(contentPane5, scrollPane);//adding everything together
        tab1.setContent(tabContent);//setting the contents


//same principle as above
        Tab tab2 = new Tab();
        tab2.setText("Months");
        tab2.setContent(new StackPane()); // Add content to the first tab
        ArrayList<ArrayList> individual2 = SeperatingInsideCharities.splitMonth(selectedList);
        Label addressLabel2 = new Label(individual2.toString());
        StackPane contentPane2 = new StackPane();
        contentPane2.getChildren().add(addressLabel2);
        ScrollPane scrollPane2 = new ScrollPane();
        scrollPane2.setContent(contentPane2);
        scrollPane2.setFitToWidth(true); // Allow the ScrollPane to resize horizontally
        VBox tabContent2 = new VBox();
        tabContent2.getChildren().addAll(contentPane2, scrollPane2);
        tab2.setContent(tabContent2);
//same principle as above
        Tab tab3 = new Tab();
        tab3.setText("Emails");
        tab3.setContent(new StackPane()); // Add content to the first tab
        ArrayList<String> individual3 = SplitIndividual.splitInListEmail(selectedList);
        Label addressLabel3 = new Label(individual3.toString());
        StackPane contentPane3 = new StackPane();
        contentPane3.getChildren().add(addressLabel3);
        ScrollPane scrollPane3 = new ScrollPane();
        scrollPane3.setContent(contentPane3);
        scrollPane3.setFitToWidth(true); // Allow the ScrollPane to resize horizontally
        VBox tabContent3 = new VBox();
        tabContent3.getChildren().addAll(contentPane3, scrollPane3);
        tab3.setContent(tabContent3);
//same principle as above
        Tab tab4 = new Tab();
        tab4.setText("Addresses");
        tab4.setContent(new StackPane()); // Add content to the first tab
        ArrayList<String> individual = SplitIndividual.splitInListDonor(selectedList, addresses);
        Label addressLabel = new Label(individual.toString());
        StackPane contentPane = new StackPane();
        contentPane.getChildren().add(addressLabel);
        ScrollPane scrollPane4 = new ScrollPane();
        scrollPane4.setContent(contentPane);
        scrollPane4.setFitToWidth(true); // Allow the ScrollPane to resize horizontally
        VBox tabContent4 = new VBox();
        tabContent4.getChildren().addAll(contentPane3, scrollPane4);
        tab4.setContent(tabContent4);
//same principle as above
        Tab tab5 = new Tab();
        tab5.setText("Money");
        tab5.setContent(new StackPane()); // Add content to the first tab
        ArrayList<String> individual1 = SplitIndividual.splitInListMoney(selectedList);
        Label addressLabel1 = new Label(individual1.toString());
        StackPane contentPane1 = new StackPane();
        contentPane1.getChildren().add(addressLabel1);
        ScrollPane scrollPane5 = new ScrollPane();
        scrollPane5.setContent(contentPane1);
        scrollPane5.setFitToWidth(true); // Allow the ScrollPane to resize horizontally
        VBox tabContent5 = new VBox();
        tabContent5.getChildren().addAll(contentPane5, scrollPane5);
        tab5.setContent(tabContent5);
//same principle as above
        Tab tab6 = new Tab();
        tab6.setText("TaxNumbers");
        tab6.setContent(new StackPane()); // Add content to the first tab
        ArrayList<String> individual6 = SplitIndividual.splitInListTax(selectedList); // Calling the method
        Label addressLabel6 = new Label(individual6.toString());
        StackPane contentPane6 = new StackPane();
        contentPane6.getChildren().add(addressLabel6);
        ScrollPane scrollPane6 = new ScrollPane();
        scrollPane6.setContent(contentPane6);
        scrollPane6.setFitToWidth(true); // Allow the ScrollPane to resize horizontally
        VBox tabContent6 = new VBox();
        tabContent6.getChildren().addAll(contentPane6, scrollPane6);
        tab6.setContent(tabContent6);
//same principle as above
        Tab tab7 = new Tab();
        tab7.setText("All Info");
        tab7.setContent(new StackPane()); // Add content to the first tab
        ArrayList<String> individual7 = SeperatingCharities.addSpace(selectedList); // Calling the method
        Label addressLabel7 = new Label(individual7.toString());
        StackPane contentPane7 = new StackPane();
        contentPane7.getChildren().add(addressLabel7);
        ScrollPane scrollPane7 = new ScrollPane();
        scrollPane7.setContent(contentPane7);
        scrollPane7.setFitToWidth(true); // Allow the ScrollPane to resize horizontally
        VBox tabContent7 = new VBox();
        tabContent7.getChildren().addAll(contentPane7, scrollPane7);
        tab7.setContent(tabContent7);

        tabPane.getTabs().addAll(tab1, tab2, tab3, tab4, tab5, tab6, tab7);//adding all the tabs to the TabPane

        Scene scene = new Scene(tabPane, 400, 300);//add everything together + define length + wodth

        // Set the scene and show the stage

        newStage.setScene(scene);
        newStage.setTitle(charity);
        newStage.show();
    }

    //this is the addDonation pane, used in: scrollPane2.setContent(AddDonation(selectedCharity, splitIndividual));, this is where we can add a donation + stuff
    public VBox AddDonation(String charity, SeperatingInsideCharities SplitIndividual) {
        VBox content = new VBox();

        // Creating all the label texts
        Label donationLabel = new Label("Enter Donation Amount:");
        Label taxNumberLabel = new Label("Enter Tax-Number:");
        Label nameLabel = new Label("Enter your name:");
        Label emailLabel = new Label("Enter your email:");


        // create a textfeild for each label
        TextField donationTextField = new TextField();
        TextField taxNumberTextField = new TextField();
        TextField nameTextField = new TextField();
        TextField emailTextField = new TextField();

        //submit button
        Button submitButton = new Button("Submit Donation");
        content.getChildren().add(submitButton);

        final ComboBox comboBoxInSelecting = new ComboBox();//again a dropdown is being created
        comboBoxInSelecting.setPromptText("Select a charity");//text on top of the dropdown
        comboBoxInSelecting.getItems().addAll(charities);//add all the charaties (which we defined above) to the dropdown, same thing as how we created last dropdown

        StackPane root = new StackPane();
        root.getChildren().add(comboBoxInSelecting);


        final Label errorLabel = new Label();//setting the errorLabel, it needs to be outside of the submitButton.setOnAction(event -> {
        errorLabel.setTextFill(Color.RED);

        content.getChildren().addAll(root, donationLabel, donationTextField, taxNumberLabel, taxNumberTextField, nameLabel, nameTextField, emailLabel, emailTextField, errorLabel);


        ///if a dropdown item is selected...
        comboBoxInSelecting.setOnAction(e -> {
            String selectedValue = (String) comboBoxInSelecting.getValue(); // Get the selected value from the ComboBox
//get the value of the comboBox dropdown

        //do not open super long, again this is the same switch logic we did above, check above
        switch (charity) {
            case "Tagtune":
                selectedList = SeperatingCharities.getTagtune();
                break;
            case "Wikibox":
                selectedList = SeperatingCharities.getWikibox();
                break;
            case "Roombo":
                selectedList = SeperatingCharities.getRoombo();
                break;
            case "Trudoo":
                selectedList = SeperatingCharities.getTrudoo();
                break;
            case "Yakitri":
                selectedList = SeperatingCharities.getYakitri();
                break;
            case "Tagfeed":
                selectedList = SeperatingCharities.getTagfeed();
                break;
            case "Podcat":
                selectedList = SeperatingCharities.getPodcat();
                break;
            case "Kwimbee":
                selectedList = SeperatingCharities.getKwimbee();
                break;
            case "Minyx":
                selectedList = SeperatingCharities.getMinyx();
                break;
            case "Ntags":
                selectedList = SeperatingCharities.getNtags();
                break;
            case "Thoughtstorm":
                selectedList = SeperatingCharities.getThoughtstorm();
                break;
            case "Devpulse":
                selectedList = SeperatingCharities.getDevpulse();
                break;
            case "Kaymbo":
                selectedList = SeperatingCharities.getKaymbo();
                break;
            case "Jabbersphere":
                selectedList = SeperatingCharities.getJabbersphere();
                break;
            case "Gigabox":
                selectedList = SeperatingCharities.getGigabox();
                break;
            case "Meemm":
                selectedList = SeperatingCharities.getMeemm();
                break;
            case "Gigazoom":
                selectedList = SeperatingCharities.getGigazoom();
                break;
            case "Dabvine":
                selectedList = SeperatingCharities.getDabvine();
                break;
            case "Skilith":
                selectedList = SeperatingCharities.getSkilith();
                break;
            case "Realcube":
                selectedList = SeperatingCharities.getRealcube();
                break;
            case "Gabvine":
                selectedList = SeperatingCharities.getGabvine();
                break;
            case "Pixoboo":
                selectedList = SeperatingCharities.getPixoboo();
                break;
            case "Skyble":
                selectedList = SeperatingCharities.getSkyble();
                break;
            case "Babbleblab":
                selectedList = SeperatingCharities.getBabbleblab();
                break;
            case "Shuffletag":
                selectedList = SeperatingCharities.getShuffletag();
                break;
            case "Thoughtsphere":
                selectedList = SeperatingCharities.getThoughtsphere();
                break;
            case "Centimia":
                selectedList = SeperatingCharities.getCentimia();
                break;
            case "Snaptags":
                selectedList = SeperatingCharities.getSnaptags();
                break;
            case "Leenti":
                selectedList = SeperatingCharities.getLeenti();
                break;
            case "Dynava":
                selectedList = SeperatingCharities.getDynava();
                break;
            case "Buzzster":
                selectedList = SeperatingCharities.getBuzzster();
                break;
            case "Twitterworks":
                selectedList = SeperatingCharities.getTwitterworks();
                break;
            case "Shufflester":
                selectedList = SeperatingCharities.getShufflester();
                break;
            case "DabZ":
                selectedList = SeperatingCharities.getDabZ();
                break;
            case "Meezzy":
                selectedList = SeperatingCharities.getMeezzy();
                break;
            case "Eire":
                selectedList = SeperatingCharities.getEire();
                break;
            case "Izio":
                selectedList = SeperatingCharities.getIzio();
                break;
            case "Photobean":
                selectedList = SeperatingCharities.getPhotobean();
                break;
            case "Yodoo":
                selectedList = SeperatingCharities.getYodoo();
                break;

        }


        //validation for alles,
        submitButton.setOnAction(event -> {//this is validating all the textbooks have all the proper info
            // Validate donation amount
            errorLabel.setText("");//clear any prev errors

            String donationAmount = donationTextField.getText();//getting the info from what the user inputted
            String donationRegex = "[-+]?[0-9]*\\.?[0-9]+"; //the regex is numbers
            if (donationAmount.isEmpty() || !donationAmount.matches(donationRegex)) {//if its not empty or if it doesnt match the regex...
                errorLabel.setText("Please fix the following errors:");
                //Label errorMessage1 = new Label("Invalid donation amount. Please enter a number and is not empty");
                //send an error message
                return;
                 // Exit the event handler if validation fails
            }else{
                SplitIndividual.getMoney().add(donationAmount);//within the splitindividual(the Splitinsidecharaties class), but we instantiated it with the name splitindividual, go to the getmoney(), the money arraylist, and add this donation amount to it
            }

            // Validate tax number
            String taxNumberTextAmount = taxNumberTextField.getText();
            String taxNumberRegex = "\\d{3}-\\d{3}-\\d{3}";//regex is for a xxx-xxx-xxx number, where x = num
            if (taxNumberTextAmount.isEmpty() || !taxNumberTextAmount.matches(taxNumberRegex)) {//same logic as above
                Label errorMessage2 = new Label("Invalid tax Number Format. Please enter in xxx-xxx-xxx and is not empty");
                content.getChildren().add(errorMessage2);
                return; // Exit the event handler if validation fails
            }else{
                SplitIndividual.getTaxNumber().add(taxNumberTextAmount);///same logic as above,
                //within the splitindividual, go to the geTaxtNumber(), the taxNumber arraylist, and add this taxnumber amount to it
            }

            // Validate name
            //same logic as above
            String nameAmount = nameTextField.getText();
            String nameRegex = "^[a-zA-Z]+$";//regex is for text
            if (nameAmount.isEmpty() || !nameAmount.matches(nameRegex)) {
                Label errorMessage3 = new Label("Invalid name Format. Please ensure the name is a String text and is not empty");
                content.getChildren().add(errorMessage3);
                return; // Exit the event handler if validation fails
            }else{
                SplitIndividual.getName().add(nameAmount);
            }

            // Validate email
            //same logic as above
            String emailAmount = emailTextField.getText();
            String emailRegex = "^[a-zA-Z0-9]+@[a-zA-Z0-9]+\\.[a-zA-Z]+$";//regex makes sure there is an @ and text before and after
            if (emailAmount.isEmpty() || !emailAmount.matches(emailRegex)) {
                Label errorMessage4 = new Label("Invalid email name Format. Please ensure your email is correct and is not empty ");
                content.getChildren().add(errorMessage4);
                return; // Exit the event handler if validation fails
            }else{
                SplitIndividual.getEmail().add(emailAmount);
            }
        });
        });
/*
        String taxNumber = taxNumberTextField.getText();
        String name = nameTextField.getText();
        String email = emailTextField.getText();
        */


        return content;
    }

    public static void main(String[] args) {
        launch();
    }
}


