package com.example.thiswillwork_two;


// in this class we have the readcsv method split
//this has everything with seeing the actual code
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Scanner;
import java.io.File;
import java.io.FileNotFoundException;
import java.util.HashMap;

import java.util.Map;

/*
ik this is super inefficient, working on a method for this, but yk it works!
 */

public class SeperatingCharities {
    ArrayList<String> allTheCharities = new ArrayList<>(Arrays.asList("Tagtune", "Wikibox", "Roombo", "Trudoo", "Yakitri", "Tagfeed", "Podcat", "Kwimbee", "Minyx", "Ntags", "Thoughtstorm", "Devpulse", "Kaymbo", "Jabbersphere", "Gigabox", "Meemm", "Gigazoom", "Dabvine", "Skilith", "Realcube", "Gabvine", "Pixoboo", "Skyble", "Babbleblab", "Shuffletag", "Thoughtsphere", "Centimia", "Snaptags", "Leenti", "Dynava", "Buzzster", "Twitterworks", "Shufflester", "DabZ", "Meezzy", "Eire", "Izio", "Photobean", "Yodoo"));
//defining an arraylist for all the charaties
    static ArrayList<String> Tagtune = new ArrayList<>();
    static ArrayList<String> Wikibox = new ArrayList<>();
    static ArrayList<String> Roombo = new ArrayList<>();
    static ArrayList<String> Trudoo = new ArrayList<>();
    static ArrayList<String> Yakitri = new ArrayList<>();
    static ArrayList<String> Tagfeed = new ArrayList<>();
    static ArrayList<String> Podcat = new ArrayList<>();
    static ArrayList<String> Kwimbee = new ArrayList<>();
    static ArrayList<String> Minyx = new ArrayList<>();
    static ArrayList<String> Ntags = new ArrayList<>();
    static ArrayList<String> Thoughtstorm = new ArrayList<>();
    static ArrayList<String> Devpulse = new ArrayList<>();
    static ArrayList<String> Kaymbo = new ArrayList<>();
    static ArrayList<String> Jabbersphere = new ArrayList<>();
    static ArrayList<String> Gigabox = new ArrayList<>();
    static ArrayList<String> Meemm = new ArrayList<>();
    static ArrayList<String> Gigazoom = new ArrayList<>();
    static ArrayList<String> Dabvine = new ArrayList<>();
    static ArrayList<String> Skilith = new ArrayList<>();
    static ArrayList<String> Realcube = new ArrayList<>();
    static ArrayList<String> Gabvine = new ArrayList<>();
    static ArrayList<String> Pixoboo = new ArrayList<>();
    static ArrayList<String> Skyble = new ArrayList<>();
    static ArrayList<String> Babbleblab = new ArrayList<>();
    static ArrayList<String> Shuffletag = new ArrayList<>();
    static ArrayList<String> Thoughtsphere = new ArrayList<>();
    static ArrayList<String> Centimia = new ArrayList<>();
    static ArrayList<String> Snaptags = new ArrayList<>();
    static ArrayList<String> Leenti = new ArrayList<>();
    static ArrayList<String> Dynava = new ArrayList<>();
    static ArrayList<String> Buzzster = new ArrayList<>();
    static ArrayList<String> Twitterworks = new ArrayList<>();
    static ArrayList<String> Shufflester = new ArrayList<>();
    static ArrayList<String> DabZ = new ArrayList<>();
    static ArrayList<String> Meezzy = new ArrayList<>();
    static ArrayList<String> Eire = new ArrayList<>();
    static ArrayList<String> Izio = new ArrayList<>();
    static ArrayList<String> Photobean = new ArrayList<>();
    static ArrayList<String> Yodoo = new ArrayList<>();

    // Getters for individual charity lists, used in HelloApplication
    public static ArrayList<String> getTagtune() {return Tagtune;}
    public static ArrayList<String> getWikibox() {return Wikibox;}
    public static ArrayList<String> getRoombo() {return Roombo;}
    public static ArrayList<String> getTrudoo() {return Trudoo;}
    public static ArrayList<String> getYakitri() {return Yakitri;}
    public static ArrayList<String> getTagfeed() {return Tagfeed;}
    public static ArrayList<String> getPodcat() {return Podcat;}
    public static ArrayList<String> getKwimbee() {return Kwimbee;}
    public static ArrayList<String> getMinyx() {return Minyx;}
    public static ArrayList<String> getNtags() {return Ntags;}
    public static ArrayList<String> getThoughtstorm() {return Thoughtstorm;}
    public static ArrayList<String> getDevpulse() {return Devpulse;}
    public static ArrayList<String> getKaymbo() {return Kaymbo;}
    public static ArrayList<String> getJabbersphere() {return Jabbersphere;}
    public static ArrayList<String> getGigabox() {return Gigabox;}
    public static ArrayList<String> getMeemm() {return Meemm;}
    public static ArrayList<String> getGigazoom() {return Gigazoom;}
    public static ArrayList<String> getDabvine() {return Dabvine;}
    public static ArrayList<String> getSkilith() {return Skilith;}
    public static ArrayList<String> getRealcube() {return Realcube;}
    public static ArrayList<String> getGabvine() {return Gabvine;}
    public static ArrayList<String> getPixoboo() {return Pixoboo;}
    public static ArrayList<String> getSkyble() {return Skyble;}
    public static ArrayList<String> getBabbleblab() {return Babbleblab;}
    public static ArrayList<String> getShuffletag() {return Shuffletag;}
    public static ArrayList<String> getThoughtsphere() {return Thoughtsphere;}
    public static ArrayList<String> getCentimia() {return Centimia;}
    public static ArrayList<String> getSnaptags() {return Snaptags;}
    public static ArrayList<String> getLeenti() {return Leenti;}
    public static ArrayList<String> getDynava() {return Dynava;}
    public static ArrayList<String> getBuzzster() {return Buzzster;}
    public static ArrayList<String> getTwitterworks() {return Twitterworks;}
    public static ArrayList<String> getShufflester() {return Shufflester;}
    public static ArrayList<String> getDabZ() {return DabZ;}
    public static ArrayList<String> getMeezzy() {return Meezzy;}
    public static ArrayList<String> getEire() {return Eire;}
    public static ArrayList<String> getIzio() {return Izio;}
    public static ArrayList<String> getPhotobean() {return Photobean;}
    public static ArrayList<String> getYodoo() {return Yodoo;}

    ///getters:
//idk.. i have this again and its never used, the method splitAsterric
    public String[] splitAsterric(String line) {
        if (line.contains("*")) {
            return line.split("\\*");
        }
        return new String[0];
    }
    // so in this one, it is actually reading the csv file, and based on the different charity
    // it is sorting them into different arraylists ive created
    public static ArrayList<String> readCSV(ArrayList<String> selectedList) {

        String csvFile = "CSV File"; // this is actually defining the CSV File, its calling it and giving it a name of CSV File
        List<List<String>> records = new ArrayList<>(); //this creates an array of Strings named 'records'
        String line; // defining a String Line
        String[] data; //definng a list of Strings named data
        // Constructor

        Scanner scanner = null;
        try {
            scanner = new Scanner(new File("CSV_File.csv"));//defining path for CSV File, making sure it exists
        } catch (FileNotFoundException e) {
            throw new RuntimeException(e);
        }

        List<String> charities = Arrays.asList(   "Tagtune", "Wikibox", "Roombo", "Trudoo", "Yakitri", "Tagfeed", "Podcat", "Kwimbee", "Minyx",
                "Ntags", "Thoughtstorm", "Devpulse", "Kaymbo", "Jabbersphere", "Gigabox", "Meemm", "Gigazoom",
                "Dabvine", "Skilith", "Realcube", "Gabvine", "Pixoboo", "Skyble", "Babbleblab", "Shuffletag",
                "Thoughtsphere", "Centimia", "Snaptags", "Leenti", "Dynava", "Buzzster", "Twitterworks", "Shufflester",
                "DabZ", "Meezzy", "Eire", "Izio", "Photobean", "Yodoo"
        );

        Map<String, List<String>> charityMap = new HashMap<>();


        while (scanner.hasNext()) {
            line = scanner.nextLine();  // Read a line, while it has a next line continue reading

            if (line.contains("Tagtune")) {///super inefficient, but whatevssss it works
                Tagtune.add(line + "*");
            }
            if (line.contains("Wikibox")) {
                Wikibox.add(line + "*");
            }
            if (line.contains("Roombo")) {
                Roombo.add(line + "*");
            }
            if (line.contains("Trudoo")) {
                Trudoo.add(line + "*");
            }
            if (line.contains("Yakitri")) {
                Yakitri.add(line + "*");
            }
            if (line.contains("Tagfeed")) {
                Tagfeed.add(line + "*");
            }
            if (line.contains("Podcat")) {
                Podcat.add(line + "*");
            }
            if (line.contains("Kwimbee")) {
                Kwimbee.add(line + "*");
            }
            if (line.contains("Minyx")) {
                Minyx.add(line + "*");
            }
            if (line.contains("Ntags")) {
                Ntags.add(line + "*");
            }
            if (line.contains("Thoughtstorm")) {
                Thoughtstorm.add(line + "*");
            }
            if (line.contains("Devpulse")) {
                Devpulse.add(line + "*");
            }
            if (line.contains("Kaymbo")) {
                Kaymbo.add(line + "*");
            }
            if (line.contains("Jabbersphere")) {
                Jabbersphere.add(line + "*");
            }
            if (line.contains("Gigabox")) {
                Gigabox.add(line + "*");
            }
            if (line.contains("Meemm")) {
                Meemm.add(line + "*");
            }
            if (line.contains("Gigazoom")) {
                Gigazoom.add(line + "*");
            }
            if (line.contains("Dabvine")) {
                Dabvine.add(line + "*");
            }
            if (line.contains("Skilith")) {
                Skilith.add(line + "*");
            }
            if (line.contains("Realcube")) {
                Realcube.add(line + "*");
            }
            if (line.contains("Gabvine")) {
                Gabvine.add(line + "*");
            }
            if (line.contains("Pixoboo")) {
                Pixoboo.add(line + "*");
            }
            if (line.contains("Skyble")) {
                Skyble.add(line + "*");
            }
            if (line.contains("Babbleblab")) {
                Babbleblab.add(line + "*");
            }
            if (line.contains("Shuffletag")) {
                Shuffletag.add(line + "*");
            }
            if (line.contains("Thoughtsphere")) {
                Thoughtsphere.add(line + "*");
            }
            if (line.contains("Centimia")) {
                Centimia.add(line + "*");
            }
            if (line.contains("Snaptags")) {
                Snaptags.add(line + "*");
            }
            if (line.contains("Leenti")) {
                Leenti.add(line + "*");
            }
            if (line.contains("Dynava")) {
                Dynava.add(line + "*");
            }
            if (line.contains("Buzzster")) {
                Buzzster.add(line + "*");
            }
            if (line.contains("Twitterworks")) {
                Twitterworks.add(line + " * ");
            }
            if (line.contains("Shufflester")) {
                Shufflester.add(line + "*");
            }
            if (line.contains("DabZ")) {
                DabZ.add(line + "*");
            }
            if (line.contains("Meezzy")) {
                Meezzy.add(line + "*");
            }
            if (line.contains("Eire")) {
                Eire.add(line + "*");
            }
            if (line.contains("Izio")) {
                Izio.add(line + "*");
            }
            if (line.contains("Photobean")) {
                Photobean.add(line + "*");
            }
            if (line.contains("Yodoo")) {
                Yodoo.add(line + "*"); //we are adding the . because it doesnt exist, and we are using it to split each line of the code
                // to be used in the next part to tell the computer this is where we're splitting the line
            }
        }
        scanner.close();
        return selectedList;//the selectedList is the one we will choose ourselvs, used in HeloApplication
        // System.out.println(Yodoo);
    }
    public static ArrayList<String> addSpace(ArrayList<String> selectedList){//this is used in ReadCSV in HelloApplicaiton, beacuse the data was just in one long line
        //makes it a teeny bit better looking
        ArrayList<String> modifiedList = new ArrayList<>(); //new list we created
        for(String selectedLists : selectedList){ //for the elements inside of the list we selected
            if (selectedLists.contains("*")){//for each asterric, which we added, ad a split, the assterick is usd to define the end of an element
                modifiedList.add("\n");
            }
            modifiedList.add(selectedLists);//add hthe selected list  along with the \n's
        }
        return modifiedList;
    }

}