package com.example.thiswillwork_two;
import java.util.ArrayList;
import java.util.List;

public class SeperatingInsideCharities {

    //in this we are defining all of the arraylists which will be isd
    SeperatingCharities charity = new SeperatingCharities();
    ArrayList<String> donor = new ArrayList<>();
    ArrayList<String> totalArray = new ArrayList<>();
    static ArrayList<String> name = new ArrayList<>();
    static ArrayList<String> email = new ArrayList<>();
    static ArrayList<String> adress = new ArrayList<>();
    static ArrayList<String> taxNumber = new ArrayList<>();
    //already have month
    static ArrayList<String> money = new ArrayList<>();
    static ArrayList<String> month = new ArrayList<>();

    //getters and setters, whuch wull be used in HelloApplication
    public static ArrayList<String> getName() {
        return name;
    }
    public static ArrayList<String> getEmail() {
        return email;
    }
    public static ArrayList<String> getAdress() {
        return adress;
    }
    public static ArrayList<String> getTaxNumber() {
        return taxNumber;
    }
    public static ArrayList<String> getMoney() {
        return money;
    }
    public static ArrayList<String> getMonth() {
        return month;
    }


    //we split specific things inside of the pre-established charity arraylists
    //this is splitting tax, its looking for -, cus all tax has that and making sure it doesnt confuse
    //it with email by ensuring it doesnt have @
    public ArrayList<String> splitInListTax(ArrayList<String> individual) {
        ArrayList<String> taxNumber = new ArrayList<>();
        taxNumber.add("Tax Number List: ");  // Add the heading
        for (String element : individual) {//splitting inside the charity list, like Photobean or a list with all charity info
            String[] splitElements = element.split("\\s+");  // Split by whitespace
            // inside of the charity list split each through a whitespace to isolate each element in the list
            for (String splitElement : splitElements) {//going through each split element in the splitelement list
                if (splitElement.contains("-") && !splitElement.contains("@")) {
                    taxNumber.add("\n");//splitting so it looks neat(er)
                    taxNumber.add(splitElement);  // Add tax number to taxnumber array
                }
            }
        }
        return taxNumber;
    }

    public ArrayList<String> splitInListEmail(ArrayList<String> individual) {//individual is our charity list we use and define later
        ArrayList<String> email = new ArrayList<>();
        email.add("Email List: ");  // Add the heading
        for (String element : individual) {//again going through each list thingy in the charity list
            String[] splitElements = element.split("\\s+");  // Split by whitespace, to isolate each element
            // Iterate over split elements
            for (String splitElement : splitElements) {
                if (splitElement.contains("@")) {
                    email.add("\n");
                    email.add(splitElement);  // Add tax number without comma or newline
                }
            }
        }
        return email;
    }
//same principle as others
    public ArrayList<String> splitInListMoney(ArrayList<String> individual) {
        ArrayList<String> email = new ArrayList<>();
        email.add("Email List: ");
        for (String element : individual) {
            String[] splitElements = element.split("\\s+");
            for (String splitElement : splitElements) {
                if (splitElement.contains("$")) {
                    email.add("\n");
                    email.add(splitElement);
                }
            }
        }
        return email;
    }


    public ArrayList<String> splitInListDonor(ArrayList<String> individual, ArrayList<String> Return) {
        for (String element : individual) {
            if (element.contains(" ")) {
                String[] splitElements = element.split("\\s+");
                for(int x = 0; x < splitElements.length; x++){//in this im trying to use the index of the elements split by the whitespace
                    //as though the adresses and stuff may be different, they're all at the same index
                    //this goes through index and based on index it adds it to a specific list
                    String increasingElement = splitElements[x];
                    if (x == 1 || x == 2){
                        name.add("\n");
                        name.add(increasingElement);
                    }
                    if (x == 4 || x == 5 || x == 6){
                        adress.add("\n");
                        adress.add(increasingElement);
                    }
                }
            }

        }
        return Return;//when using this, choose to return any of the arraylists, like money or taxNumber
    }

    //we split the assterric, i forget why, but i think identification reasons
    public static String[] splitAsterric(String line) {//used in the splitMonth class
        if (line.contains("*")) {
            return line.split("\\*");
        }
        return new String[0];
    }
    //superrrr inefficient, but works
    //goes through months and looks for any indicator of a month and adds it to a month list
    public static ArrayList<ArrayList> splitMonth(List<String> inputList) {//as the months are different, i created a seperte class to seperate
        //the months

        ArrayList<String> January = new ArrayList<>();
        January.add("Jan: ");
        ArrayList<String> February = new ArrayList<>();
        February.add("Feb: ");
        ArrayList<String> March = new ArrayList<>();
        March.add("Mar: ");
        ArrayList<String> April = new ArrayList<>();
        April.add("Apr: ");
        ArrayList<String> May = new ArrayList<>();
        May.add("May: ");
        ArrayList<String> June = new ArrayList<>();
        June.add("Jun: ");
        ArrayList<String> July = new ArrayList<>();
        July.add("Jul: ");
        ArrayList<String> August = new ArrayList<>();
        August.add("Aug: ");
        ArrayList<String> September = new ArrayList<>();
        September.add("Sep: ");
        ArrayList<String> October = new ArrayList<>();
        October.add("Oct: ");
        ArrayList<String> November = new ArrayList<>();
        November.add("Nov: ");
        ArrayList<String> December = new ArrayList<>();
        November.add("Dec: ");

        ArrayList<ArrayList> allMonths = null;
        for (String splitElement : inputList) { //input list is the same thing as individual in the others, its just the charity list
            String[] splitElements = splitElement.split("\\s+");  // Split by whitespace
            // Iterate over split elements
            for (String element : splitElements) {
                if (element.contains("01/") || element.contains("1/")) {
                    January.add(element + "\n");
                } else if (element.contains("02/") || element.contains("2/")) {
                    February.add(element + "\n");
                } else if (element.contains("03/") || element.contains("3/")) {
                    March.add(element + "\n");
                } else if (element.contains("04/") || element.contains("4/")) {
                    April.add(element + "\n");
                } else if (element.contains("05/") || element.contains("5/")) {
                    May.add(element + "\n");
                } else if (element.contains("06/") || element.contains("6/")) {
                    June.add(element + "\n");
                } else if (element.contains("07/") || element.contains("7/")) {
                    July.add(element + "\n");
                } else if (element.contains("08/") || element.contains("8/")) {
                    August.add(element + "\n");
                } else if (element.contains("09/") || element.contains("9/")) {
                    September.add(element + "\n");
                } else if (element.contains("10/")) {
                    October.add(element + "\n");
                } else if (element.contains("11/")) {
                    November.add(element + "\n");
                } else if (element.contains("12/")) {
                    December.add(element + "\n");
                }
            }
            allMonths = new ArrayList<>();//creating an arraylist of all the months, so we can return all the months
            allMonths.add(January);
            allMonths.add(February);
            allMonths.add(March);
            allMonths.add(April);
            allMonths.add(May);
            allMonths.add(June);
            allMonths.add(July);
            allMonths.add(August);
            allMonths.add(September);
            allMonths.add(October);
            allMonths.add(November);
            allMonths.add(December);
        }
        return allMonths;//returns all the months
    }

}

//the issue is its reading each array as a whole






