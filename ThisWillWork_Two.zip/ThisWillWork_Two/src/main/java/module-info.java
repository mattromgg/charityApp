module com.example.thiswillwork_two {
    requires javafx.controls;
    requires javafx.fxml;

    requires org.kordamp.bootstrapfx.core;

    opens com.example.thiswillwork_two to javafx.fxml;
    exports com.example.thiswillwork_two;
}